import { BrowserRouter as Router, Routes, Route } from "react-router";
import SignIn from "./pages/AuthPages/SignIn";
import SignUp from "./pages/AuthPages/SignUp";
import NotFound from "./pages/OtherPage/NotFound";
import UserProfiles from "./pages/UserProfiles";
import Blank from "./pages/Blank";
import AppLayout from "./layout/AppLayout";
import { ScrollToTop } from "./components/common/ScrollToTop";
import WelcomePage from "./pages/welcome/WelcomePage";
import AmbassadorDashboard from "./pages/Dashboard/AmbassadorDashboard";
import RequestsPage from "./pages/Demandes/RequestsPage";
import RequestDetailPage from "./pages/Demandes/RequestDetailPage";
import UsersManagementPage from "./pages/utilisateurs/UsersManagementPage";
import AppointmentsPage from "./pages/appointments/MyAppointmentsPage";
import MyAgendaPage from "./pages/appointments/MyAgendaPage";

export default function App() {
  return (
    <>
      <Router>
        <ScrollToTop />
        <Routes>
          {/* Welcome Page */}
          <Route index path="/" element={<WelcomePage />} />
          {/* Dashboard Layout */}
          <Route element={<AppLayout />}>
            <Route index path="/dashboard" element={<AmbassadorDashboard />} />

            {/* Others Page */}
            
            <Route path="/profile" element={<UserProfiles />} />
            <Route path="/blank" element={<Blank />} />


            {/* Demande */}
            <Route path="/service/demandes" element={<RequestsPage />} />
            <Route path="/service/demandes/:id" element={<RequestDetailPage />} />

            {/* Utilisateurs */}
            <Route path="/service/gestion/utilisateurs" element={<UsersManagementPage />} />
            <Route path="/agent/rendez-vous" element={<AppointmentsPage />} />
            <Route path="/agent/rendez-vous/mon-agenda" element={<MyAgendaPage />} />
          </Route>

          {/* Auth Layout */}
          <Route path="/signin" element={<SignIn />} />
          <Route path="/signup" element={<SignUp />} />

          {/* Fallback Route */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Router>
    </>
  );
}
